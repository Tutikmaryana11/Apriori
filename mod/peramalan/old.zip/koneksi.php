<?php
/*
 * Configuration Database
 */
return array(
    'host' => "localhost",
    'username' => "root",
    'password' => "",
    'dbname' => "penjualan",
    // 'port' => "", // sementara menggunakan port bawaan
);

?>
