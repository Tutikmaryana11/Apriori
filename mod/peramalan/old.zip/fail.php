<?php
	if(!isset($_SESSION['login_user'])){
		header('location: ../../login.php'); // Mengarahkan ke Home Page
	}

	if(isset($_SESSION['peramalan']) AND $_SESSION['peramalan'] <> 'TRUE')
	{
		echo"<div class='w3-container w3-red'><p>Dilarang mengakses file ini.</p></div>";
		die();
	}

	//link buat paging
	$linkaksi = 'med.php?mod=peramalan';

	if(isset($_GET['act']))
	{
		$act = $_GET['act'];
		$linkaksi .= '&act='.$act;
	}
	else
	{
		$act = '';
	}

	$aksi = 'mod/peramalan/act_peramalan.php';

	switch ($act) {
		case 'form':
			if(!empty($_GET['id']))
			{
				$act = "$aksi?mod=peramalan&act=edit";
				$query = mysql_query("SELECT * FROM tb_peramalan WHERE peramalan_id = '$_GET[id]'");
				$temukan = mysql_num_rows($query);
				if($temukan > 0)
				{
					$c = mysql_fetch_assoc($query);
				}
				else
				{
					header("location:med.php?mod=peramalan");
				}

			}
			else
			{
				$act = "$aksi?mod=peramalan&act=simpan";
			}

			echo"<div class='w3-container w3-small w3-pale-green w3-leftbar w3-border-green'>
				<h4 style='margin-bottom:0;padding-bottom:0;'>Form Peramalan</h4>
				<p style='margin-top:0;padding-top:0;'><i>Form Input Peramalan</i></p>
			</div>";

			echo"<form class='w3-small' method='POST' action='$act'>
				<table>
					<tr>
						<td width='220px'><label class='w3-label'>KATEGORI ID</label></td>
						<td width='10px'>:</td>
						<td><input type='text' name='id' class='w3-input' placeholder='Tidak Perlu Diisi' value='"?><?php echo isset($c['peramalan_id']) ? $c['peramalan_id'] : '';?><?php echo"'"?> <?php echo isset($c['peramalan_id']) ? ' readonly' : ' ';?><?php echo" required readonly> 
						</td>
						
					</tr>
					<tr>
						<td><label class='w3-label'>NAMA KATEGORI</label></td>
						<td>:</td>
						<td><input type='text' name='nama_peramalan' class='w3-input' placeholder='Nama Peramalan' value='"?><?php echo isset($c['nama_peramalan']) ? $c['nama_peramalan'] : '';?><?php echo"' required>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td align='right'><button type='submit' name='submit' value='simpan' class='w3-btn'><i class='fa fa-save'></i> Simpan Data</button>&nbsp;

						<button type='button' class='w3-btn w3-orange' onclick='history.back()'><i class='fa fa-rotate-left'></i> Kembali</button></td>
					</tr>
				</table>
					
			</form>";
		break;

		default :

		//start default case iterasi 1
			echo"<div class='w3-container w3-small w3-pale-green w3-leftbar w3-border-green'>
				<h4 style='margin-bottom:0;padding-bottom:0;'>Peramalan</h4>
				<p style='margin-top:0;padding-top:0;'><i>Data Semua Peramalan</i></p>
			</div>";

			flash('example_message');

			echo"<table style='margin-top:12px;'>
				<tr>
					<td>
						<div class='w3-container w3-small w3-pale-red w3-leftbar w3-border-red'>
							<h6 style='margin-bottom:0;padding-bottom:0;'>Iterasi 1</h6>
							<p style='margin-top:0;padding-top:0;'><i>Untuk 1-itemset hitung dan scan database untuk mendapatkan pola frequent dari support.</i></p>
						</div>
					</td>
					<td align='right'><a href='med.php?mod=peramalan' class='w3-btn w3-dark-grey w3-small'><i class='fa fa-refresh'></i> Refresh</a>
					</td>
				</tr>
				
			</table>";

			echo"<div style='margin-top:12px;margin-bottom:12px;'>
			<table class='w3-table w3-striped w3-bordered w3-tiny w3-hoverable tbl'>
				<thead>
					<tr class='w3-yellow'>
						<th width='20px'>NO</th>
						<th>Item Set</th>
						<th>Support Count</th>
						<th>Support</th>
					</tr>
				</thead>
				<tbody>";

				$query = "SELECT nama_barang, count(*) as jumlah FROM tb_detail_penjualan tdp join tb_barang b on b.kode_barang=tdp.kode_barang group by b.kode_barang order by jumlah asc";
				$query_bagi = "SELECT count(*) as pembagi from tb_penjualan";

				

				$sql_kul = mysql_query($query);
				$sql_kuls = mysql_query($query_bagi);
				$pembagi = mysql_fetch_array($sql_kuls);
	
					$no = 1;
					while ($m = mysql_fetch_assoc($sql_kul)) {
						$hasil = $m['jumlah']/$pembagi['pembagi']*100;
						echo"<tr>
						
							<td>$no</td>
							<td>$m[nama_barang]</td>
							<td>$m[jumlah]</td>
							<td>$hasil%</td>
						
						</tr>";
						$no++;
					}
				

				echo"</tbody>

			</table></div>";


			//start default case iterasi 2

			flash('example_message');

			echo"<table style='margin-top:12px;'>
				<tr>
					<td>
						<div class='w3-container w3-small w3-pale-red w3-leftbar w3-border-red'>
							<h6 style='margin-bottom:0;padding-bottom:0;'>Iterasi 2</h6>
							<p style='margin-top:0;padding-top:0;'><i>Untuk 2-itemset hitung dan scan database untuk mendapatkan pola frequent dari support.</i></p>
						</div>
					</td>
					<td align='right'><a href='med.php?mod=peramalan' class='w3-btn w3-dark-grey w3-small'><i class='fa fa-refresh'></i> Refresh</a>
					</td>
				</tr>
				
			</table>";

			echo"<div style='margin-top:12px;margin-bottom:12px;'>
			<table class='w3-table w3-striped w3-bordered w3-tiny w3-hoverable tbl'>
				<thead>
					<tr class='w3-yellow'>
						<th width='20px'>NO</th>
						<th>Item Set</th>
						<th>Support Count</th>
						<th>Support</th>
					</tr>
				</thead>
				<tbody>";

				$query = "SELECT nama_barang, count(*) as jumlah FROM tb_detail_penjualan tdp join tb_barang b on b.kode_barang=tdp.kode_barang group by b.kode_barang order by jumlah asc";

				$query_bagi = "SELECT count(*) as pembagi from tb_penjualan";

				

				$sql_kul = mysql_query($query);
				$sql_kuls = mysql_query($query_bagi);
				$pembagi = mysql_fetch_array($sql_kuls);
	
					$no = 1;
					while ($m = mysql_fetch_assoc($sql_kul)) {
						$hasil = $m['jumlah']/$pembagi['pembagi']*100;
						echo"<tr>
						
							<td>$no</td>
							<td>$m[nama_barang]</td>
							<td>$m[jumlah]</td>
							<td>$hasil%</td>
						
						</tr>";
						$no++;
					}

			
				echo"</tbody>

			</table></div>";
		break;
	}

	
?>