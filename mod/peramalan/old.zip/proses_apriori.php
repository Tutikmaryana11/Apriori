
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/templatemo-misc.css">
<!-- <link rel="stylesheet" href="css/templatemo-style.css"> -->
<div class='w3-container w3-small w3-pale-green w3-leftbar w3-border-green'>
    <h4 style='margin-bottom:0;padding-bottom:0;'>Peramalan</h4>
    <p style='margin-top:0;padding-top:0;'><i>Form Input Peramalan</i></p>
</div>


<?php
include_once "database.php";
include_once "fungsi.php";
include_once "mining.php";
include_once "display_mining.php";
//object database class
$db_object = new database();

$pesan_error = $pesan_success = "";
if (isset($_GET['pesan_error'])) {
    $pesan_error = $_GET['pesan_error'];
}
if (isset($_GET['pesan_success'])) {
    $pesan_success = $_GET['pesan_success'];
}

if (isset($_POST['submit'])) {
// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
// exit();
    ?>

    <?php
    $can_process = true;
    if (empty($_POST['min_support']) || empty($_POST['min_confidence'])) {
        $can_process = false;
        ?>
        <script> location.replace("?menu=proses_apriori&pesan_error=Min Support dan Min Confidence harus diisi");</script>
        <?php
    }
    if(!is_numeric($_POST['min_support']) || !is_numeric($_POST['min_confidence'])){
        $can_process = false;
        ?>
        <script> location.replace("?menu=proses_apriori&pesan_error=Min Support dan Min Confidence harus diisi angka");</script>
        <?php
    }
            //  01/09/2016 - 30/09/2016

    if($can_process){
        $tgl = explode(" - ", $_POST['range_tanggal']);
        $start = format_date($tgl[0]);
        $end = format_date($tgl[1]);

        if(isset($_POST['id_process'])){
            $id_process = $_POST['id_process'];
                    //delete hitungan untuk id_process
            reset_hitungan($db_object, $id_process);

                    //update log process
            $field = array(
                "start_date"=>$start,
                "end_date"=>$end,
                "min_support"=>$_POST['min_support'],
                "min_confidence"=>$_POST['min_confidence']
            );
                        // echo "<pre>";
                        // print_r($field);
                        // echo "</pre>";
                        // exit();
            $where = array(
                "id"=>$id_process
            );
            $query = $db_object->update_record("process_log", $field, $where);
        }
        else{
                    //insert log process
            $field_value = array(
                "start_date"=>$start,
                "end_date"=>$end,
                "min_support"=>$_POST['min_support'],
                "min_confidence"=>$_POST['min_confidence']
            );
            $query = $db_object->insert_record("process_log", $field_value);
            $id_process = $db_object->db_insert_id();
        }
                //show form for update
        ?>
        <form class='w3-small' method='POST' action=''>
    <table>
        <tr>
            <td><label>Min Support: </label>
                <input name="min_support" type="text" class="w3-input" placeholder="Min Support">
            </td>
        </tr>
        <tr>
            <td>
                <label>Min Confidence: </label>
                <input name="min_confidence" type="text" class="w3-input" placeholder="Min Confidence">
            </td>
        </tr>
    <tr>
        <td align='left'>
            <!-- <input type="hidden" name="id_process" value="<?php echo $id_process; ?>"> -->
            <div class="form-group">
                <input name="submit" type="submit" value="Proses" class="btn btn-success">
            </div>
        </td>
    </tr>
        <tr>
            <td>
               <label>Tanggal: </label>
               <div class="input-group">
                <input type="text" class="w3-input pull-right" name="range_tanggal"
                                           id="reservation" required="" placeholder="Date range">
            </div><!-- /.input group -->
        </td>
    </tr>
    <tr>
        <td>
            <div class="input-group">
                <input name="search_display" type="submit" value="Search" class="btn btn-default">
            </div>
        </td>
    </tr>
</table>

</form>


        <?php


        echo "Min Support Absolut: " . $_POST['min_support'];
        echo "<br>";
        $sql = "SELECT COUNT(*) FROM transaksi 
        WHERE transaction_date BETWEEN '$start' AND '$end' ";
        $res = $db_object->db_query($sql);
        $num = $db_object->db_fetch_array($res);
        $minSupportRelatif = ($_POST['min_support']/$num[0]) * 100;
        echo "Min Support Relatif: " . $minSupportRelatif;
        echo "<br>";
        echo "Min Confidence: " . $_POST['min_confidence'];
        echo "<br>";
        echo "Start Date: " . $_POST['range_tanggal'];
        echo "<br>";



        $result = mining_process($db_object, $_POST['min_support'], $_POST['min_confidence'],
            $start, $end, $id_process);
        if ($result) {
            display_success("Proses mining selesai");
        } else {
            display_error("Gagal mendapatkan aturan asosiasi");
        }

        display_process_hasil_mining($db_object, $id_process);
    }
    ?>
 
<?php
} else {
    $where = "ga gal";
    if(isset($_POST['range_tanggal'])){
        $tgl = explode(" - ", $_POST['range_tanggal']);
        $start = format_date($tgl[0]);
        $end = format_date($tgl[1]);

        $where = " WHERE transaction_date "
        . " BETWEEN '$start' AND '$end'";
    }
    $sql = "SELECT
    *
    FROM
    transaksi ".$where;

    $query = $db_object->db_query($sql);
    $jumlah = $db_object->db_num_rows($query);
    ?>
<form class='w3-small' method='POST' action=''>
    <table>
        <tr>
            <td><label>Min Support: </label>
                <input name="min_support" type="text" class="w3-input" placeholder="Min Support">
            </td>
        </tr>
        <tr>
            <td>
                <label>Min Confidence: </label>
                <input name="min_confidence" type="text" class="w3-input" placeholder="Min Confidence">
            </td>
        </tr>
    <tr>
        <td align='left'>
            <!-- <input type="hidden" name="id_process" value="<?php echo $id_process; ?>"> -->
            <div class="form-group">
                <input name="submit" type="submit" value="Proses" class="btn btn-success">
            </div>
        </td>
    </tr>

            <tr>
            <td>
               <label>Tanggal: </label>
               <div class="input-group">
                <input type="text" class="w3-input pull-right" name="range_tanggal"
                                           id="reservation" required="" placeholder="Date range">
            </div><!-- /.input group -->
        </td>
    </tr>
    <tr>
        <td>
            <div class="input-group">
                <input name="search_display" type="submit" value="Search" class="btn btn-default">
            </div>
        </td>
    </tr>
</table>

</form>

    <?php
    if (!empty($pesan_error)) {
        display_error($pesan_error);
    }
    if (!empty($pesan_success)) {
        display_success($pesan_success);
    }


    echo "Jumlah data: " . $jumlah . "<br>";
    if ($jumlah == 0) {
        echo "Data kosong...";
    } 
    else {
        ?>
        <table class='table table-bordered table-striped  table-hover'>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Produk</th>
            </tr>
            <?php
            $no = 1;
            while ($row = $db_object->db_fetch_array($query)) {
                echo "<tr>";
                echo "<td>" . $no . "</td>";
                echo "<td>" . $row['transaction_date'] . "</td>";
                echo "<td>" . $row['produk'] . "</td>";
                echo "</tr>";
                $no++;
            }
            ?>
        </table>
        <?php
    }
    ?>
<!-- </div>
</div> -->
<!-- </div> -->
<?php
}
?>

<script>
    $(function () {
    //Date range picker
    $('#reservation').daterangepicker(
        {format: 'DD/MM/YYYY'}
        );
    $('#daterange-btn').daterangepicker(
    {
      ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
    startDate: moment().subtract(29, 'days'),
    endDate: moment()
},
function (start, end) {
  $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
}
);

});
</script>
